import os
from PIL import Image
from PIL import ImageEnhance
img = Image.open('puppy.jpg')


def image_to_str(image):
    print('sequencing...')
    image = image.convert('RGB')
    color_strings = []
    height, width = image.size[1], image.size[0]
    print(width, height)
    for y in range(0, height):
        for x in range(0, width):
            r, g, b = image.getpixel((x, y))
            pixelColor = "{r}_{g}_{b}".format(r=r, g=g, b=b)
            color_strings.append(pixelColor)

    image_str = ' '.join(color_strings)
    print("done!")
    return image_str

def str_to_image(image_str, width, height):
        canvas = (width, height)

        #from Pillow API
        newImg = Image.new('RGB', canvas, (100,100,100,0))
        pixel_data = newImg.load()

        color_strings = image_str.split()
        y = -1
        for pixel in range(0, width * height):
            r, g, b = color_strings[pixel].split('_')
            x = pixel % width
            if x == 0:
                y = y+1
            pixel_data[x, y] = (int(r), int(g), int(b))
        newImg.show()
        return newImg

pup = image_to_str(img)
str_to_image(pup, 360, 270)

