
class MarkovChain(dict):
	def __init__(self):
		super(MarkovChain, self).__init__()

	def addSet(self, iter):
		
	#def __iter__(self):