from tkinter import *
from PIL import Image, ImageTk
import os
import string
import math
import random
import pyprind
import sys
import time

def distance(p1, p2):
    return math.sqrt((p1[0]-p2[0])**2+(p1[1]-p2[1])**2)

################################################################

def init(data):
    data.mode = "start"
    data.image = None
    data.timerCounter = 0
    data.imageName = "jackieo.jpg"
    data.title1 = "Markov Art Generator"
    data.title2 = "-press something to start-"
    data.inputString=""
    data.printWarning = False
    data.fill1, data.fill2, data.fill3 = "black", "black", "black"
    data.order = 1
    data.title3="Generating"
    data.inputNum = 0
    data.desiredOutput = ""
    data.chain = None
    data.outImage = None
def mousePressed(event, data):
    if (data.mode == "start"): startMousePressed(event, data)
    elif (data.mode == "input"):   inputMousePressed(event, data)
    elif (data.mode == "input2"):   input2MousePressed(event, data)
    elif (data.mode == "loading"):       loadingMousePressed(event, data)
    elif (data.mode == "output"):   outputMousePressed(event, data)

def keyPressed(event, data):
    if (data.mode == "start"): startKeyPressed(event, data)
    elif (data.mode == "input"):   inputKeyPressed(event, data)
    elif (data.mode == "input2"):   input2KeyPressed(event, data)
    elif (data.mode == "loading"):       loadingKeyPressed(event, data)
    elif (data.mode == "output"):   outputKeyPressed(event, data)

def timerFired(data):
    if (data.mode == "start"): startTimerFired(data)
    elif (data.mode == "input"):   inputTimerFired(data)
    elif (data.mode == "input2"):   input2TimerFired(data)
    elif (data.mode == "loading"):       loadingTimerFired(data)
    elif (data.mode == "output"):   outputTimerFired(data)

def redrawAll(canvas, data):
    if (data.mode == "start"): startRedrawAll(canvas, data)
    elif (data.mode == "input"):   inputRedrawAll(canvas, data)
    elif (data.mode == "input2"):   input2RedrawAll(canvas, data)
    elif (data.mode == "loading"):       loadingRedrawAll(canvas, data)
    elif (data.mode == "output"):   outputRedrawAll(canvas, data)
    
################################################################

def startMousePressed(event, data):
    pass
def startKeyPressed(event, data):
    if event.keysym:
        data.mode = "input"
def startTimerFired(data):
    data.timerCounter+=1
    if data.timerCounter % 6 == 0:
        data.imageName="load1.png"
    if data.timerCounter % 6 == 1:
        data.title1 = "Markov Art Generator"
        data.title2 = "@press something to start%"
        data.imageName="load2.png"
    if data.timerCounter % 6 == 2:
        data.title1 = "MarkoV Art Generator"
        data.title2 = "6press something to startB"
        data.imageName="load3.png"
    if data.timerCounter % 6 == 3:
        data.title1 = "Markov Art_Generator"
        data.title2 = "#press something to start*"
        data.imageName="load1.png"
    if data.timerCounter % 6 == 4:
        data.title1 = "Markov-Art Generator"
        data.title2 = "$press something to start^"
        data.imageName="load2.png"
    if data.timerCounter % 6 == 5:
        data.title1 = "!Markov Art Generator!"
        data.title2 = "-press ANYTHING to start&"
        data.imageName="load3.png"

def startRedrawAll(canvas, data):
    
    image = Image.open(data.imageName)
    image = image.resize((data.width, data.height), Image.ANTIALIAS)
    tkImage = ImageTk.PhotoImage(image)
    data.image = tkImage
    canvas.create_image(0, 0, image=tkImage, anchor="nw")
    canvas.create_text(data.width/2, data.height/2-20,
                       text=data.title1, font="Arial 36 bold", fill = "white")
    canvas.create_text(data.width/2, data.height/2+20,
                       text=data.title2, font="Arial 26", fill = "white")

################################################################

def inputMousePressed(event, data):
    pass
def inputKeyPressed(event, data):
    if event.keysym == "BackSpace":
        data.inputString = data.inputString[:-1]
    elif event.keysym == "period":
        data.inputString += "."
    elif len(event.keysym)==1:
        data.inputString+=event.keysym
    elif event.keysym == "Return":
        if (os.path.exists(data.inputString) and (data.inputString.endswith(".jpg") or \
            data.inputString.endswith(".png"))):
            data.mode="input2"
        else:
            data.printWarning=True
    else:
        data.printWarning=True
def inputTimerFired(data):
    pass
def inputRedrawAll(canvas, data):
    canvas.create_rectangle(0, 0, data.width, data.height,fill="black", width=0)
    canvas.create_text(data.width/2, data.height/2-30,
        text="Type a filename:", font="Arial 26", fill = "white")
    canvas.create_text(data.width/2, data.height/2,
            text=data.inputString, font="Arial 26", fill = "white")
    canvas.create_text(data.width/2, data.height/2+30,
        text="Press enter to submit.", font="Arial 26", fill = "white") 
    if data.printWarning:
        canvas.create_text(data.width/2, data.height/2+60,
            text="File path must be alphanumeric and valid.", font="Arial 26", fill = "red")  
    #take input for image and type of chain
    #check image size
    #valid input
    #scale?
    #do chain
    #store model for later
    #ready button

################################################################

def input2MousePressed(event, data):
    mouseLoc = (event.x, event.y)
    c1Loc = (data.width/4, data.height/4)
    c2Loc = (data.width/4, data.height/2)
    c3Loc = (data.width/4, data.height*3/4)
    bigR = 12
    if distance(mouseLoc, c1Loc) <= bigR:
        data.fill1 = "white"
        data.fill2 = "black"
        data.fill3 = "black"
    if distance(mouseLoc, c2Loc) <= bigR:
        data.fill1 = "black"
        data.fill2 = "white"
        data.fill3 = "black"
    if distance(mouseLoc, c3Loc) <= bigR:
        data.fill1 = "black"
        data.fill2 = "black"
        data.fill3 = "white"
def input2KeyPressed(event, data):
    if data.fill2=="white":
        if event.keysym == "BackSpace":
            data.inputNum = data.inputNum//10
        elif len(event.keysym)==1 and event.keysym.isdigit():
            data.inputNum=data.inputNum*10+int(event.keysym)
        elif event.keysym == "Return":
            data.order=data.inputNum
            data.mode="loading"
            time.sleep(.150) 
            generateModelandOutput(data)
    elif data.fill1=="white" or data.fill3=="white":
        if event.keysym == "Return":
            data.mode="loading"
            time.sleep(.150)
            generateModelandOutput(data)
def input2TimerFired(data):
    pass
def input2RedrawAll(canvas, data):
    canvas.create_rectangle(0, 0, data.width, data.height,fill="black", width=0)
    canvas.create_text(data.width/2, data.height/8,
        text="Select a model and press enter:", font="Arial 26", fill = "white")
    cx1,cy1 = data.width/4, data.height/4
    cx2,cy2 = data.width/4, data.height/2
    cx3,cy3 = data.width/4, data.height*3/4
    bigR=12
    littleR=10
    canvas.create_text(data.width/4+20, cy1,
    text="Order 1 Linear Markov", font="Arial 26", fill = "white", anchor="w")
    canvas.create_oval(cx1-bigR,cy1-bigR,cx1+bigR,cy1+bigR,fill="white")
    canvas.create_oval(cx1-littleR,cy1-littleR,cx1+littleR,cy1+littleR,fill=data.fill1)
    if data.fill1 == "white":
        data.order = 1
        data.desiredOutput = "linear"

    canvas.create_text(data.width/4+20, cy2,
        text="Order n Linear Markov", font="Arial 26", fill = "white", anchor="w")
    canvas.create_oval(cx2-bigR,cy2-bigR,cx2+bigR,cy2+bigR,fill="white")
    canvas.create_oval(cx2-littleR,cy2-littleR,cx2+littleR,cy2+littleR,fill=data.fill2)

    if data.fill2 == "white":
        canvas.create_text(data.width/2-10, data.height/2+30,
            text="Type an order:", font="Arial 26", fill = "white", anchor="e")
        if data.inputNum != 0:
            canvas.create_text(data.width/2, data.height/2+30,
                text=data.inputNum, font="Arial 26", fill = "white", anchor="w")
        data.desiredOutput = "linear"
        
    canvas.create_text(data.width/4+20, cy3,
        text="Neighbor Markov", font="Arial 26", fill = "white", anchor="w")
    canvas.create_oval(cx3-bigR,cy3-bigR,cx3+bigR,cy3+bigR,fill="white")
    canvas.create_oval(cx3-littleR,cy3-littleR,cx3+littleR,cy3+littleR,fill=data.fill3)

    if data.fill3 == "white":
        #print("still in development!")
        data.desiredOutput = "neighbor"

################################################################

def generateModelandOutput(data):
    if data.desiredOutput == "linear":
        img = Image.open(data.inputString)
        colors = imageToListOfColors(img)
        data.chain = LinearMarkov(data.order,colors)
        data.outImage = data.chain.generateOutput(500,500)
        data.outImage.save('out.png')
        data.mode="output"
def loadingMousePressed(event, data):
    pass
def loadingKeyPressed(event, data):
    pass
def loadingTimerFired(data):
    data.timerCounter += 1
    if data.timerCounter % 3 == 0:
        data.imageName="load1.png"
        data.title3 = "Generating."
    if data.timerCounter % 3 == 1:
        data.imageName="load2.png"
        data.title3 = "Generating.."
    if data.timerCounter % 3 == 2:
        data.imageName="load3.png"
        data.title3 = "Generating..."
def loadingRedrawAll(canvas, data):
    image = Image.open(data.imageName)
    image = image.resize((data.width, data.height), Image.ANTIALIAS)
    tkImage = ImageTk.PhotoImage(image)
    data.image = tkImage
    canvas.create_image(0, 0, image=tkImage, anchor="nw")
    canvas.create_text(data.width/2, data.height/2-20,
                       text=data.title3, font="Arial 36 bold", fill = "white")
    #how do i know when it's done?
    #add something between
    #watch image output?
    #would need to be hella fast or done by rows or something

################################################################

def outputMousePressed(event, data):
    pass
def outputKeyPressed(event, data):
    if event.keysym == "r":
        data.mode="input"
    if event.keysym == "g":
        data.outImage = data.chain.generateOutput(500,500)
        data.outImage.save('out.png')
def outputTimerFired(data):
    pass
def outputRedrawAll(canvas, data):
    image = Image.open('out.png')
    image = image.resize((data.width, data.height), Image.ANTIALIAS)
    tkImage = ImageTk.PhotoImage(image)
    data.outImage = tkImage
    canvas.create_image(0, 0, image=tkImage, anchor="nw")
    canvas.create_text(data.width/2, data.height/2,
                       text="Press g to generate another output from model.", font="Arial 16", fill = "black")
    canvas.create_text(data.width/2, data.height,
                       text="Press r to go back to input.", font="Arial 16", fill = "black", anchor="s")
    #redo generation
    #go back to input
    #save image

################################################################

def run(width=300, height=300):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        canvas.create_rectangle(0, 0, data.width, data.height,
                                fill='white', width=0)
        redrawAll(canvas, data)
        canvas.update()    

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.width = width
    data.height = height
    data.timerDelay = 100 # milliseconds
    init(data)
    # create the root and the canvas
    root = Tk()
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.pack()
    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed
    print("bye!")

class FrequencyTable(dict):
    def __init__(self):
        super(FrequencyTable, self).__init__()
        self.keyCount = 0  
        self.valueCount = 0  

    def update(self, lst):
        # i chose to do this because counting totals for the entries and such
        #is a hell of a lot cheaper here than looping through in randomColor
        for item in lst:
            if item not in self:               
                self.keyCount += 1
            self[item] = 1 + self.get(item,0)
            self.valueCount += 1

    def randomColor(self):
        #https://stackoverflow.com/questions/40927221/how-to-choose-keys-from-a-python-dictionary-based-on-weighted-probability
        #effectively copied and modified this code
        randomIndex = random.randint(0, self.valueCount-1)
        total = 0
        for key, value in self.items():
            total += value
            #once past randomIndex we stop and return
            if(randomIndex < total):
                return key

class LinearMarkov():
    #i didnt base my code on these but i did look at them so im citing them
    #to clarify, I designed the algorithms and wrote all the code for the models
    #https://en.wikipedia.org/wiki/Markov_model
    #https://hackernoon.com/from-what-is-a-markov-model-to-here-is-how-markov-models-work-1ac5f4629b71
    def __init__(self, order=1, colors=None):
        if order < 1 or not isinstance(order, int):
            #so it doesnt break
            order=1
        self.order = order
        self.markov_model = dict()
        if colors:
            self.addToModel(colors)

    def addToModel(self, data):
        print('modeling...')
        if self.order == 1:
            for i in range(0, len(data)-1):
                if data[i] in self.markov_model:
                    self.markov_model[data[i]].update([data[i+1]])
                else:
                    self.markov_model[data[i]] = FrequencyTable()
                    self.markov_model[data[i]].update([data[i+1]])

        if self.order > 1:
            for i in range(len(data)-self.order):
                window = tuple(data[i: i+self.order])
                if window in self.markov_model:
                    self.markov_model[window].update([tuple(data[i+1: i+self.order+1])])
                else:
                    self.markov_model[window] = FrequencyTable()
                    self.markov_model[window].update([tuple(data[i+1: i+self.order+1])])

            last = tuple(data[len(data)-self.order:len(data)])
            #this maps the last tuple to the first so it completes the chain
            self.markov_model[last] = FrequencyTable()
            self.markov_model[last].update([tuple(data[0:self.order])])

    def generateOutput(self, width, height):
        print('generating...')
        output = []
        #l is the iterations for the final image
        l = width*height
        #returns a 'random' output form the current model based on order
        if self.order == 1:
            currKey = random.choice(list(self.markov_model.keys()))
            output = [currKey]
            for i in range(l):
                currTable = self.markov_model[currKey]
                randomCol= currTable.randomColor()
                currKey = randomCol
                output.append(currKey)

        if self.order > 1:
            currKey = random.choice(list(self.markov_model.keys()))
            output = list(currKey)
            for i in range(l):
                currTable = self.markov_model[currKey]
                randomCol = currTable.randomColor()
                currKey = randomCol
                output.append(randomCol[self.order-1])
        finalImg = listOfColorsToImage(output, width, height)
        return finalImg

def imageToListOfColors(image):
    #https://stackoverflow.com/questions/11064786/get-pixels-rgb-using-pil
    #referenced API and above link
    print('converting...')
    rgbImage = image.convert('RGB')
    colors = []
    height, width = rgbImage.size[1], rgbImage.size[0]
    print(str(width) + "by" + str(height))
    for y in range(0, height):
        for x in range(0, width):
            r, g, b = rgbImage.getpixel((x, y))
            pixelColor = "%s_%s_%s"%(r,g,b)
            colors.append(pixelColor)

    return colors

def listOfColorsToImage(lst, width, height):
        #referenced API
        canvas = (width, height)
        l = width * height
        #from Pillow API
        image = Image.new('RGB', canvas, (100,100,100,0))
        pixel_data = image.load()

        y = -1
        for pixel in range(l):
            r, g, b = lst[pixel].split('_')
            x = pixel % width
            #each new row add to y
            if x == 0:
                y = y+1
            pixel_data[x, y] = (int(r), int(g), int(b))
        return image

run(500, 500)